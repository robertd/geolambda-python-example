"""
Rasterio commandline interface components
"""
